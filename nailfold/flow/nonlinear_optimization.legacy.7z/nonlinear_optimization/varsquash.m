function [squash] = varsquash(varname)
% Return whether to put the variable through a sigmoid function to impose
% limits on its value.

switch varname
    case {'Q', 'F', 'uu', 'vv'},
        squash = false;
    otherwise,
        squash = false;
end
