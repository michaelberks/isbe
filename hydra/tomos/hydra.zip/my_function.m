function model = my_function(file_in, other_args)

% Main function that actually does soemthing
%

% Load in data from file_in
% data = load(file_in);
display(file_in);

% Do something clever with data
display(other_args);

%Return model
model = 0;

